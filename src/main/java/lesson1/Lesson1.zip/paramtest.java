package lesson1;

public class paramtest {
    public static void main(String args[]) {
        System.out.println("\n第一个参数是：" + args[0]);
        System.out.println("\n第二个参数是：" + args[1]);
    }
}
